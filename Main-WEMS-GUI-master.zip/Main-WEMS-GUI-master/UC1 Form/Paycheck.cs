﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UC1_Form
{
    public class Paycheck
    {
        DateTime dateSent;
        double payAmt;
        double basePay;
        double hourRate;
        double hoursWorked;
    }
}
