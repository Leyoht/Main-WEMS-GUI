﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UC1_Form
{
    public class siteSupervisor : Management
    {
        public void assign_employee()
        {
            throw new System.NotImplementedException();
        }

        public void check_project_status()
        {
            throw new System.NotImplementedException();
        }

        public void modify_equipment_report()
        {
            throw new System.NotImplementedException();
        }

        public void generate_equipment_report()
        {
            throw new System.NotImplementedException();
        }

        public void request_location_assignment()
        {
            throw new System.NotImplementedException();
        }
    }
}